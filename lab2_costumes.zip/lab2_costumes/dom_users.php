<?php
$xmlFile = 'popular.xml';

// Створюємо новий об'єкт DOMDocument
$dom = new DOMDocument('1.0', 'UTF-8');
$dom->formatOutput = true; 

if (file_exists($xmlFile)) {
    // Якщо файл існує, завантажуємо його в DOM
    $dom->load($xmlFile);
    // Отримуємо кореневий елемент документа
    $root = $dom->documentElement;
    echo "<p>Файл <strong>$xmlFile</strong> знайдено. Кореневий елемент: &lt;" . $root->nodeName . "&gt;</p>";
} else {
    // Якщо файл не існує, створюємо кореневий елемент <users>
    $root = $dom->createElement('users');
    // Додаємо кореневий елемент до DOM документа
    $dom->appendChild($root);
    // Зберігаємо новий XML файл з кореневим елементом
    $dom->save($xmlFile);
    echo "<p>Файл <strong>$xmlFile</strong> не знайдено. Створено новий файл з кореневим елементом &lt;users&gt;.</p>";
}
?>
