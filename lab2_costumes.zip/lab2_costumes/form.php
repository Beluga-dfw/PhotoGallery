<?php
require_once  'controllers/AuthController.php';

$controller = new AuthController();
$controller->handleRequest();

$model = $controller->model;

$error = $model->error;
$success = $model->success;
$name = $model->name;
$email = $model->email;
$nickname = $model->nickname;
$domain = $model->domain;
$suffix = $model->suffix;

include 'views/authForm.php';
?>