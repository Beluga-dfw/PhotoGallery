<?php
require_once 'models/CostumeModel.php';
require_once 'helpers.php';

use App\Models\CostumeModel;

class CostumeController {
    private $model;

    public function __construct() {
        $this->model = new CostumeModel();
    }

    public function handleRequest() {
        if (!isset($_GET['id'])) {
            header("Location: home.php");
            exit;
        }

        $id = $_GET['id'];
        $costume = $this->model->getById($id);

        if (!$costume) {
            echo "Костюм не знайдено.";
            exit;
        }

        if (isset($_POST['delete'])) {
            $this->model->delete($id);
            header("Location: home.php");
            exit;
        }

        if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST['update'])) {
            $name = $_POST["name"];
            $category = $_POST["category"];
            $size = $_POST["size"];
            $price = $_POST["price"];
            $available = $_POST["available"];
            $descriptionRaw = $_POST["description"];
            $descriptionRaw = str_replace('Тестовий опис', 'Унікальний костюм для святкових подій', $descriptionRaw);
            $description = convertTextToHtml($descriptionRaw);
            $photoPath = $costume['photo'];

            if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
                $filename = time() . "_" . basename($_FILES["photo"]["name"]);
                $target = "uploads/" . $filename;
                move_uploaded_file($_FILES["photo"]["tmp_name"], $target);
                $photoPath = $target;
            }

            $this->model->update($id, $name, $category, $size, $price, $available, $photoPath, $description);
            header("Location: costume.php?id=$id");
            exit;
        }

        $isEdit = isset($_GET['edit']);

        return ['costume' => $costume, 'isEdit' => $isEdit];
    }
}
