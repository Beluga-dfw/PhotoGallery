<?php
require_once __DIR__ . '/../models/db.php';
use App\Database;

  require_once 'core/DatabaseFactory.php';
$db = DatabaseFactory::getAdapter();

$search = $_GET['search'] ?? '';
$category = $_GET['category'] ?? '';
$costumes = [];

foreach ($db->getAll() as $c) {
    $matchName = $search === '' || stripos($c['name'], $search) !== false;
    $matchCategory = $category === '' || mb_strtolower($c['category']) === mb_strtolower($category);

    if ($matchName && $matchCategory) {
        $costumes[] = $c;
    }
}

require_once __DIR__ . '/../views/home.view.php';
