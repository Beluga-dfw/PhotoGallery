<?php
require_once 'models/db.php';
require_once 'helpers.php';

use App\Database;

class AddController {
    private $db;

    public function __construct() {
   require_once 'core/DatabaseFactory.php';
$this->db = DatabaseFactory::getAdapter();

    }

    public function handleRequest() {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $this->processForm();
        } else {
            $this->showForm();
        }
    }

    private function processForm() {
        $name = $_POST["name"];
        $category = $_POST["category"];
        $size = $_POST["size"];
        $price = $_POST["price"];
        $available = $_POST["available"];
        $descriptionRaw = $_POST["description"];
        $descriptionRaw = str_replace('Тестовий опис', 'Унікальний костюм для святкових подій', $descriptionRaw);
        $description = convertTextToHtml($descriptionRaw);

        $photoPath = null;
        if (isset($_FILES["photo"]) && $_FILES["photo"]["error"] == 0) {
            $originalName = basename($_FILES["photo"]["name"]);
            $cleanName = preg_replace('/\s+/', '_', $originalName);
            $filename = time() . "_" . $cleanName;
            $target = "uploads/" . $filename;
            move_uploaded_file($_FILES["photo"]["tmp_name"], $target);
            $photoPath = $target;
        }

        $this->db->add($name, $category, $size, $price, $available, $photoPath, $description);

        header("Location: home.php");
        exit;
    }

    private function showForm() {
        include 'views/add.view.php'; // сюда вынеси твой HTML-код формы
    }
}
