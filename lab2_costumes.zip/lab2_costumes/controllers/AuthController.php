<?php
require_once 'models/AuthModel.php';

class AuthController {
    public $model;

    public function __construct() {
        $this->model = new AuthModel();
    }

    public function handleRequest() {
        if ($_SERVER["REQUEST_METHOD"] === "POST") {
            $this->model->loadData($_POST);
            if ($this->model->validate()) {
                $this->model->parseEmail();
                $this->model->success = true;
            } else {
                $this->model->success = false;
            }
        }
    }

    public function getViewData() {
        return [
            'error' => $this->model->error ?? '',
            'success' => $this->model->success ?? false,
            'name' => $this->model->name ?? '',
            'email' => $this->model->email ?? '',
            'nickname' => $this->model->nickname ?? '',
            'domain' => $this->model->domain ?? '',
            'suffix' => $this->model->suffix ?? '',
        ];
    }
}
