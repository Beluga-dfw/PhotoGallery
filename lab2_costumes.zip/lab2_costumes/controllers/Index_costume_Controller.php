<?php
require_once 'models/db.php';
use App\Database;

class CostumeController {
    private $costumes;

    public function __construct() {
         require_once 'core/DatabaseFactory.php';
$db = DatabaseFactory::getAdapter();
        $this->costumes = $db->getAll();
    }

    public function getCostumes() {
        return $this->costumes;
    }
}
?>
