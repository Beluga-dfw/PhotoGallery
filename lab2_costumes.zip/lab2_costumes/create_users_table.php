<?php
/**
 * Створює таблицю `users` у базі database.sqlite, якщо її ще не існує.
 * Відпрацюйте цей скрипт один раз, після чого його можна видалити.
 */

// 1) Шлях до файлу бази
$dbPath = __DIR__ . '/database.sqlite';

try {
    // 2) Підключаємося до SQLite
    $pdo = new PDO('sqlite:' . $dbPath);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // 3) Виконуємо CREATE TABLE IF NOT EXISTS
    $sql = "
    CREATE TABLE IF NOT EXISTS users (
        id        INTEGER PRIMARY KEY AUTOINCREMENT,
        firstname TEXT    NOT NULL,
        lastname  TEXT    NOT NULL,
        email     TEXT    NOT NULL UNIQUE,
        password  TEXT    NOT NULL
    );
    ";
    $pdo->exec($sql);

    echo "Таблицю users успішно створено (або вона вже існувала).\n";

    // 4) (Опційно) можемо додати тестового користувача
    // УРЛЯ ЗАХЕШУВАННЯ ПАРОЛЯ: password_hash('12345', PASSWORD_DEFAULT)
    // Виконайте команду нижче, якщо хочете створити тестовий обліковий запис:
    /*
    $testEmail = 'test@example.com';
    $testPassword = password_hash('12345', PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("
        INSERT OR IGNORE INTO users (firstname, lastname, email, password)
        VALUES ('Test', 'User', :email, :passwd)
    ");
    $stmt->execute([
        ':email'  => $testEmail,
        ':passwd' => $testPassword
    ]);
    echo "Тестовий користувач (test@example.com / 12345) створено, якщо його не було.\n";
    */

} catch (Exception $e) {
    echo "Помилка при створенні таблиці users: " . htmlspecialchars($e->getMessage());
}
