<?php

class Router
{
    private static $instance = null;

    private function __construct() {} // забороняємо створення через new
    private function __clone() {}     // забороняємо клонування
    private function __wakeup() {}    // забороняємо десеріалізацію

    public static function getInstance(): Router
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    public function route()
    {
        $url = $_GET['url'] ?? '';
        $url = trim($url, '/');
        $parts = explode('/', $url);

        $controllerName = !empty($parts[0]) ? ucfirst($parts[0]) . 'Controller' : 'HomeController';
        $methodName = $parts[1] ?? 'index';
        $params = array_slice($parts, 2);

        $controllerFile = '../app/controllers/' . $controllerName . '.php';

        if (file_exists($controllerFile)) {
            require_once $controllerFile;
            if (class_exists($controllerName)) {
                $controller = new $controllerName();
                if (method_exists($controller, $methodName)) {
                    call_user_func_array([$controller, $methodName], $params);
                } else {
                    echo "Метод <b>$methodName</b> не знайдено.";
                }
            } else {
                echo "Клас контролера <b>$controllerName</b> не знайдено.";
            }
        } else {
            echo "Файл контролера <b>$controllerFile</b> не знайдено.";
        }
    }
}
