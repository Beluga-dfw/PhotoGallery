<?php
require_once 'DatabaseAdapter.php';

class MongoDatabaseAdapter implements DatabaseAdapter {
    public function getAll() {
        return [
            ['name' => 'Костюм Мумії', 'category' => 'Жахи', 'size' => 'L', 'price' => 300],
            ['name' => 'Костюм Єдинорога', 'category' => 'Фентезі', 'size' => 'M', 'price' => 400]
        ];
    }

    public function getById($id) {
        return ['name' => 'Фейковий костюм', 'category' => 'Фентезі', 'size' => 'S', 'price' => 250];
    }

    public function add($name, $category, $size, $price, $available, $photo, $description) {
        echo "Додавання до MongoDB: $name\n";
    }

    public function delete($id) {
        echo "Видалення з MongoDB: $id\n";
    }
}
