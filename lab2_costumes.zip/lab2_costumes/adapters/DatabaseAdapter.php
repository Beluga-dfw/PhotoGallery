<?php
namespace Adapters;
interface DatabaseAdapter {
    public function getAll();
    public function getById($id);
    public function add($name, $category, $size, $price, $available, $photo, $description);
    public function delete($id);
}
