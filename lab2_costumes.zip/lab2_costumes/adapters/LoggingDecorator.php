<?php
namespace Adapters;

class LoggingDecorator implements DatabaseAdapter {
    private $wrapped;

    // Конструктор приймає адаптер, який буде обгортатися (декоруватися)
    public function __construct(DatabaseAdapter $adapter) {
        $this->wrapped = $adapter;
    }

    // Отримати всі записи
    public function getAll() {
        return $this->wrapped->getAll();
    }

    // Отримати запис за ID
    public function getById($id) {
        return $this->wrapped->getById($id);
    }

    // Додати новий костюм із попереднім логуванням
    public function add($name, $category, $size, $price, $available, $photo, $description) {
        // Логування — наприклад, запис у лог-файл:
        error_log("Додаємо костюм: $name, категорія: $category, ціна: $price");

        // Виклик оригінального методу адаптера
        $this->wrapped->add($name, $category, $size, $price, $available, $photo, $description);
    }

    // Видалити костюм з логуванням
    public function delete($id) {
        error_log("Видаляємо костюм з id: $id");
        $this->wrapped->delete($id);
    }
}
