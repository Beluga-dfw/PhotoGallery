<?php
namespace Adapters;
require_once 'adapters/DatabaseAdapter.php';
require_once 'models/db.php';

use App\Database;

class SqliteDatabaseAdapter implements DatabaseAdapter {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function getAll() {
        return $this->db->getAll();
    }

    public function getById($id) {
        return $this->db->getById($id);
    }

    public function add($name, $category, $size, $price, $available, $photo, $description) {
        $this->db->add($name, $category, $size, $price, $available, $photo, $description);
    }

    public function delete($id) {
        $this->db->delete($id);
    }
}
