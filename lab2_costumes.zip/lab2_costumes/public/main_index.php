<?php

require_once '../core/Router.php';
require_once '../core/Controller.php';
require_once __DIR__ . '/../controllers/NewPageController.php';

$router->get('/newpage', [NewPageController::class, 'index']);


$router = Router::getInstance();
$router->route();
