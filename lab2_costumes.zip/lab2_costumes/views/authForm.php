<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Авторизація</title>
    
    <style>
        /* Основний контейнер для форми */
        .container {
            max-width: 400px;
            margin: 60px auto;
            background: #f8f9fa;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 0 15px rgba(0,0,0,0.1);
            font-family: Arial, sans-serif;
        }

        /* Стиль самої форми */
        .auth-form {
            display: flex;
            flex-direction: column;
            gap: 20px;
        }

        /* Стиль для міток (label) */
        .auth-form label {
            font-weight: 600;
            font-size: 16px;
            color: #333;
        }

        /* Стиль для інпутів */
        .auth-form input {
            width: 100%  !important;
            padding: 12px 15px;
            font-size: 16px;
            border: 1.5px solid #ccc;
            border-radius: 8px;
            transition: border-color 0.3s ease;
        }

        /* При фокусі на полі змінюємо колір рамки */
        .auth-form input:focus {
            border-color: #0d6efd;
            outline: none;
            box-shadow: 0 0 8px rgba(13, 110, 253, 0.4);
        }

        /* Стиль кнопки */
        .auth-button {
            padding: 18px 20px !important;
            font-size: 20px !important;
            font-weight: 500 !important;
            color: white;
            background-color:rgb(13, 95, 49)  !important;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s ease;
        }

        /* Ефект наведеня на кнопку */
        .auth-button:hover {
            background-color:rgb(47, 148, 86)  !important;
        }

        /* Стиль для повідомлень */
        p {
            font-weight: 600;
            font-size: 16px;
            margin-bottom: 20px;
            text-align: center;
        }

        /* Стиль для повідомлення про успіх */
        .success-message {
            text-align: center;
            font-size: 24px;
            color: rgb(2, 105, 42);
            font-weight: 700;
        }

        /* Відмітка "галочка" */
        .success-message .checkmark {
            font-size: 48px;
            display: block;
            margin-bottom: 10px;
        }

        /* Стиль для кнопки "На головну" */
        .btn-home {
            display: inline-block;
            padding: 12px 20px;
            font-size: 20px;
            background-color: rgb(29, 45, 92);
            color: white;
            border-radius: 8px;
            text-decoration: none;
            font-weight: 400;
            transition: background-color 0.3s ease;
            margin: 0 auto;
            text-align: center;
        }
        .btn-home:hover {
            background-color:rgb(69, 107, 163);
        }
    </style>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<header>PHOTO GALLERY</header>
<nav>
   <a href="home.php">Головна</a>
     <a href="popular.php">Популярні</a>
    <a href="add.php">Додати костюм</a>
    <a href="index.php">Адмінка</a>
</nav>

<div class="container" style="max-width: 500px; margin: 0 auto;">
    <h2 style="text-align:center;">Авторизація</h2>

    <?php if ($error): ?>
        <!-- Виводимо повідомлення про помилку -->
        <p style="color:red;"><?= htmlspecialchars($error) ?></p>

        <!-- Форма авторизації при наявності помилки -->
        <form method="POST" class="auth-form">
            <label>Ім’я:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

            <button type="submit" class="auth-button">Увійти</button>
        </form>

    <?php elseif ($success): ?>
        <!-- Повідомлення про успішну авторизацію -->
        <div class="success-message">
    <span class="checkmark">✅</span>
    Авторизовано!<br>
    <strong>Никнейм:</strong> <?= htmlspecialchars($nickname) ?><br>
    <strong>Домен:</strong> <?= htmlspecialchars($domain) ?><br>
    <strong>Суффикс:</strong> <?= htmlspecialchars($suffix) ?>
</div>

        <!-- Кнопка повернення на головну -->
        <div style="text-align:center; margin-top: 20px;">
            <a href="home.php" class="btn-home">На головну</a>
        </div>

    <?php else: ?>
        <!-- Виводимо форму, якщо немає ні помилки, ні успіху (перший вхід) -->
        <form method="POST" class="auth-form">
            <label>Ім’я:</label>
            <input type="text" name="name" value="<?= htmlspecialchars($name) ?>" required>

            <label>Email:</label>
            <input type="email" name="email" value="<?= htmlspecialchars($email) ?>" required>

            <button type="submit" class="auth-button">Увійти</button>
        </form>
    <?php endif; ?>
</div>
</body>
</html>
