<?php
// lang.php
session_start();

// 1) Список доступних мов
$available_languages = ['uk','en','ru','de'];

// 2) Якщо передано GET-параметр ?lang=xx
if (isset($_GET['lang']) && in_array($_GET['lang'], $available_languages)) {
    $_SESSION['lang'] = $_GET['lang'];
}

// 3) Встановлюємо поточний код мови або за замовчуванням 'uk'
$lang_code = $_SESSION['lang'] ?? 'uk';

// 4) Шлях до файлу перекладу, наприклад lang/uk.php, lang/en.php і т.д.
$lang_file = __DIR__ . "/lang/{$lang_code}.php";

// 5) Підключаємо перекладний масив
if (file_exists($lang_file)) {
    $TRANSLATIONS = include $lang_file;
} else {
    $TRANSLATIONS = [];
}

// 6) Функція, що повертає переклад або сам ключ, якщо переклад не знайдено
function __($key) {
    global $TRANSLATIONS;
    return $TRANSLATIONS[$key] ?? $key;
}
