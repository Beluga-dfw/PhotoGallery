<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Список костюмів</title>
    <link rel="stylesheet" href="css/style.css">
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            background-color: #f0f2f5;
        }
        header {
            background-color: #0d1117;
            color: white;
            padding: 30px;
            font-size: 32px;
            text-align: center;
            font-weight: bold;
        }
        nav {
            background-color: #161b22;
            padding: 15px;
            text-align: center;
        }
        nav a {
            color: #ffc107;
            margin: 0 20px;
            font-size: 18px;
            text-decoration: none;
            font-weight: bold;
        }
        .container {
            max-width: 1200px;
            margin: 40px auto;
            background: white;
            border-radius: 10px;
            padding: 30px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
        }
        h1 {
            font-size: 28px;
            margin-bottom: 20px;
        }
        .table-container {
            overflow-x: auto;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            background-color: #fff;
        }
        th, td {
            padding: 14px 20px;
            text-align: center;
            border-bottom: 1px solid #dee2e6;
        }
        th {
            background-color: #f8f9fa;
            font-weight: 600;
        }
        tr:hover {
            background-color: #f1f3f5;
        }
        a {
            color: #0d6efd;
        }
        a:hover {
            text-decoration: underline;
        }
        .add-link {
            display: inline-block;
            margin-bottom: 20px;
            background: #0d6efd;
            color: white;
            padding: 10px 20px;
            border-radius: 6px;
            text-decoration: none;
            font-weight: 500;
        }
        .add-link:hover {
            background: #084298;
        }
    </style>
</head>
<body>
<header>🎝️ Оренда костюмів</header>
<nav>
   <a href="home.php">Головна</a>
     <a href="popular.php">Популярні</a>
    <a href="add.php">Додати костюм</a>
    <a href="form.php">Авторизація</a>
</nav>

<div class="container">
    <h1>Список костюмів</h1>
    <a href="add.php">➕ Додати новий костюм</a>
    <div class="table-container">
        <table>
            <tr>
                <th>ID</th>
                <th>Назва</th>
                <th>Категорія</th>
                <th>Розмір</th>
                <th>Ціна</th>
                <th>Доступність</th>
                <th>Дії</th>
            </tr>
            <?php foreach ($costumes as $costume): ?>
                <tr>
                    <td><?= $costume['id'] ?></td>
                    <td><?= htmlspecialchars($costume['name']) ?></td>
                    <td><?= htmlspecialchars($costume['category']) ?></td>
                    <td><?= htmlspecialchars($costume['size']) ?></td>
                    <td><?= htmlspecialchars($costume['price']) ?> грн</td>
                    <td><?= $costume['available'] ?></td>
                    <td>
                        <a href="costume.php?id=<?= $costume['id'] ?>&edit=1">Редагувати</a> |
                        <a href="costume.php?id=<?= $costume['id'] ?>">Переглянути</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</div>
</body>
</html>
