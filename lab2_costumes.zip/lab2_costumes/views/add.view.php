<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>PHOTO GALLERY</title>
    <link rel="stylesheet" href="css/style.css">

    <style>

.add-form {
        max-width: 600px;
        margin: 40px auto;
        background: white;
        padding: 30px;
        border-radius: 12px;
        box-shadow: 0 6px 15px rgba(0, 0, 0, 0.1);
        font-family: 'Arial', sans-serif;
    }
    .add-form h2 {
        text-align: center;
        margin-bottom: 20px;
        font-weight: 700;
    }
    .add-form label {
        display: block;
        margin-top: 15px;
        font-weight: 600;
        color: #333;
    }
    .add-form input[type="text"],
    .add-form input[type="number"],
    .add-form select,
    .add-form textarea,
    .add-form input[type="file"] {
        width: 100%;
        padding: 10px;
        margin-top: 5px;
        border: 1px solid #ccc;
        border-radius: 8px;
        font-size: 16px;
        transition: border-color 0.3s ease;
    }
    .add-form input[type="text"]:focus,
    .add-form input[type="number"]:focus,
    .add-form select:focus,
    .add-form textarea:focus,
    .add-form input[type="file"]:focus {
        border-color:rgb(47, 0, 255);
        outline: none;
    }
    .add-form textarea {
        resize: vertical;
        min-height: 80px;
    }
    .add-form button {
        margin-top: 25px;
        padding: 12px 25px;
        background:rgb(8, 38, 102);
        color: white;
        border: none;
        border-radius: 8px;
        font-size: 20px;
        font-weight: 600;
        cursor: pointer;
        transition: background 0.3s ease;
        display: block;
        width: 100%;
    }
    .add-form button:hover {
        background:rgb(66, 124, 212);
    }

    </style>

</head>
<body>
    <header>PHOTO GALLERY</header>
    <nav>
       <a href="home.php">Головна</a>
     <a href="popular.php">Популярні</a>
    <a href="index.php">Адмінка</a>
    <a href="form.php">Авторизація</a>
    </nav>

   <div class="container">
    <form class="add-form" method="post" enctype="multipart/form-data">
        <h2>Додати новий костюм</h2>
        <label for="name">Назва:</label>
        <input type="text" id="name" name="name" required>

        <label for="category">Категорія:</label>
        <input type="text" id="category" name="category" required>

        <label for="size">Розмір:</label>
        <input type="text" id="size" name="size" required>

        <label for="price">Ціна:</label>
        <input type="number" id="price" name="price" required>

        <label for="description">Опис:</label>
        <textarea id="description" name="description" rows="4" required></textarea>

        <label for="available">Доступність:</label>
        <select id="available" name="available">
            <option value="так">так</option>
            <option value="ні">ні</option>
        </select>

        <label for="photo">Фото костюма:</label>
        <input type="file" id="photo" name="photo">

        <button type="submit">Додати</button>
    </form>
</div>

</body>
</html>
