<?php
class AuthModel {
    public $name = '';
    public $email = '';
    public $error = '';
    public $success = false;
    public $nickname = '';
    public $domain = '';
    public $suffix = '';

    public function loadData(array $post) {
        $this->name = trim($post['name'] ?? '');
        $this->email = trim($post['email'] ?? '');
    }

    public function validate() {
        if (!preg_match("/^[\w\-\.]+@([\w-]+\.)+[\w-]{2,4}$/", $this->email)) {
            $this->error = "Невірний формат e-mail.";
            return false;
        }
        return true;
    }

    public function parseEmail() {
        $atPos = strpos($this->email, '@');
        $this->nickname = substr($this->email, 0, $atPos);

        $domainWithSuffix = substr($this->email, $atPos + 1);
        $lastDotPos = strrpos($domainWithSuffix, '.');

        $this->domain = substr($domainWithSuffix, 0, $lastDotPos);
        $this->suffix = substr($domainWithSuffix, $lastDotPos + 1);
    }
}
?>
