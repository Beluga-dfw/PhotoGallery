<?php
namespace App\Models;

require_once __DIR__ . '/../models/db.php';

use App\Database;

class CostumeModel {
    private $db;

    public function __construct() {
        $this->db = new Database();
    }

    public function getById($id) {
        return $this->db->getById($id);
    }

    public function delete($id) {
        $this->db->delete($id);
    }

    public function update($id, $name, $category, $size, $price, $available, $photo, $description) {
        $this->db->update($id, $name, $category, $size, $price, $available, $photo, $description);
    }
}
