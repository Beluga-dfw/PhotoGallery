<?php
// Абстрактний клас костюма
abstract class Costume {
    abstract public function getDescription();
}

// Конкретні моделі костюмів
class VampireCostume extends Costume {
    public function getDescription() {
        return "Костюм вампіра - страшно і стильно";
    }
}

class WitchCostume extends Costume {
    public function getDescription() {
        return "Костюм відьми - загадково і містично";
    }
}

class ClownCostume extends Costume {
    public function getDescription() {
        return "Костюм клоуна - весело і яскраво";
    }
}

// Фабрика для створення костюмів
class CostumeFactory {
    public static function create($type) {
        switch (strtolower($type)) {
            case 'vampire':
                return new VampireCostume();
            case 'witch':
                return new WitchCostume();
            case 'clown':
                return new ClownCostume();
            default:
                throw new Exception("Невідомий тип костюма: $type");
        }
    }
}

// Приклад використання фабрики
$types = ['vampire', 'witch', 'clown'];

echo "<h1>Приклади створення костюмів за допомогою фабрики</h1>";

foreach ($types as $type) {
    $costume = CostumeFactory::create($type);
    echo "<p><strong>" . ucfirst($type) . ":</strong> " . $costume->getDescription() . "</p>";
}
?>
