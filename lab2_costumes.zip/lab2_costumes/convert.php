<?php
function stringToHtml($text) {
    $text = htmlspecialchars($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    $text = nl2br($text);
    return $text;
}

function htmlToString($html) {
    $text = preg_replace('/<br\s*\/?>/i', "\n", $html);
    $text = html_entity_decode($text, ENT_QUOTES | ENT_HTML5, 'UTF-8');
    return $text;
}

$result = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $inputText = $_POST['input_text'] ?? '';
    $direction = $_POST['direction'] ?? 'to_html';

    if ($direction === 'to_html') {
        $result = stringToHtml($inputText);
    } else {
        $result = htmlToString($inputText);
    }
}
?>

<!DOCTYPE html>
<html lang="uk">
<head>
    <meta charset="UTF-8">
    <title>Перетворення рядків HTML</title>
</head>
<body>
    <h1>Перетворення рядків та файлів до HTML і назад</h1>
    <form method="post" action="">
        <textarea name="input_text" rows="10" cols="60" placeholder="Введіть текст або HTML тут..."><?= htmlspecialchars($_POST['input_text'] ?? '') ?></textarea><br>
        <label><input type="radio" name="direction" value="to_html" <?= (!isset($_POST['direction']) || $_POST['direction'] === 'to_html') ? 'checked' : '' ?>> Текст → HTML</label><br>
        <label><input type="radio" name="direction" value="to_text" <?= (isset($_POST['direction']) && $_POST['direction'] === 'to_text') ? 'checked' : '' ?>> HTML → Текст</label><br><br>
        <button type="submit">Перетворити</button>
    </form>

    <?php if ($result !== ''): ?>
        <h2>Результат:</h2>
        <pre style="background:#eee; padding:10px;"><?= htmlspecialchars($result) ?></pre>
    <?php endif; ?>
</body>
</html>
