function createNotification(content) {
    return {
        type: 'notification',
        content,
        date: new Date().toLocaleString()
    };
}

function sendNotificationToAll(server, notification) {
    server.clients.forEach(client => {
        if (client.readyState === 1) {
            client.send(JSON.stringify(notification));
        }
    });
}

module.exports = {
    createNotification,
    sendNotificationToAll
};