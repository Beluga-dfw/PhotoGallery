const WebSocket = require('ws');
const { createNotification, sendNotificationToAll } = require('./notifications');

const server = new WebSocket.Server({ port: 8080 });

let messages = []; // масив для зберігання всіх повідомлень

server.on('connection', ws => {
    // Надсилаємо всі попередні повідомлення новому клієнту
    messages.forEach(msg => ws.send(JSON.stringify(msg)));

        const welcome = createNotification('Новий користувач підключився!');
    sendNotificationToAll(server, welcome);

    ws.on('message', data => {
        const msg = JSON.parse(data);
        msg.date = new Date().toLocaleString(); // додаємо дату
          msg.type = msg.type || 'chat';

        messages.push(msg); // зберігаємо повідомлення

        // Надсилаємо нове повідомлення всім клієнтам
        server.clients.forEach(client => {
            if (client.readyState === WebSocket.OPEN) {
                client.send(JSON.stringify(msg));
            }
        });

        const notification = createNotification(`Нове повідомлення від ${msg.name}`);
    sendNotificationToAll(server, notification);
    });
});

console.log(' WebSocket сервер запущено на ws://localhost:8080');
