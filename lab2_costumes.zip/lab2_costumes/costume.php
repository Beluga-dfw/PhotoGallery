<?php
require_once 'controllers/CostumeController.php';

$controller = new CostumeController();
$data = $controller->handleRequest();

require 'views/costumeView.php';
