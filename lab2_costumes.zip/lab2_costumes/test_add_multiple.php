<?php
require_once  'models/db.php';
use App\Database; //простір імен

$db = new Database();

$testCostumes = [
    [
        'name' => 'Тестовий костюм 1',
        'category' => 'Категорія 1',
        'size' => 'S',
        'price' => 100,
        'available' => 'так',
        'photo' => 'uploads/test1.png',
        'description' => 'Опис тестового костюму 1'
    ],
    [
        'name' => 'Тестовий костюм 2',
        'category' => 'Категорія 2',
        'size' => 'M',
        'price' => 200,
        'available' => 'ні',
        'photo' => 'uploads/test2.png',
        'description' => 'Опис тестового костюму 2'
    ],
];

try {
    $db->addMultipleCostumes($testCostumes);
    echo "Тестові костюми додані успішно!\n";
} catch (PDOException $e) {
    echo "Помилка при додаванні: " . $e->getMessage() . "\n";
}

$allCostumes = $db->getAll();
print_r($allCostumes);
